package com.example.helpmelogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        final AppCompatButton signUpBtn= findViewById(R.id.signUpBtn);
        final TextView loginBtn=findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //login activity
              startActivity(new Intent(Register.this,Login.class));
              finish();
            }
        });
        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //sign up settings here!!
                //then open up main activity after successful sign up

             startActivity(new Intent(Register.this,MainActivity.class));
            }
        });
    }
@Override
    public void onBackPressed(){
        startActivity(new Intent(Register.this,Login.class));
        finish();
}

}