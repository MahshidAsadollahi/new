package com.example.helpmelogin;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText username=findViewById(R.id.username);
        final EditText password=findViewById(R.id.password);
        final AppCompatButton loginBtn=findViewById(R.id.loginBtn);
        final TextView signUpBtn=findViewById(R.id.signUpBtn);
        signUpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//sign up activity
               startActivity(new Intent(Login.this,Register.class));
               finish();
            }
        });
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String usernameTxt=username.getText().toString();
                final String passwordTxt=password.getText().toString();

                if (usernameTxt.isEmpty()||passwordTxt.isEmpty()){
                    Toast.makeText(Login.this,"Please enter your username or password ",Toast.LENGTH_SHORT).show();
                }
                else {

                }


                startActivity(new Intent(Login.this,MainActivity.class));
                finish();
            }
        });
    }
}